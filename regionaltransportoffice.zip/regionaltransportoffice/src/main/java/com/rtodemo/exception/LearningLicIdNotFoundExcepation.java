package com.rtodemo.exception;

public class LearningLicIdNotFoundExcepation extends RuntimeException
{
	public LearningLicIdNotFoundExcepation(String message) 
	{
		super(message);
	}

}
