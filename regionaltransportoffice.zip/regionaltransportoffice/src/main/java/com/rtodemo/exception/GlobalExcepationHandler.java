package com.rtodemo.exception;

import org.springframework.http.HttpStatus; 
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@ResponseStatus
public class GlobalExcepationHandler extends ResponseEntityExceptionHandler
{
	@ExceptionHandler(AdminrtoIdNotFoundExcepation.class)
	public ResponseEntity<ErrorMassage> handleAdminrtoExcepation(AdminrtoIdNotFoundExcepation aex,WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND, aex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er) ;
		
	}
	
	@ExceptionHandler(ChallanIdNotfoundExcepation.class)
	public ResponseEntity<ErrorMassage> handleChallanExcepation(ChallanIdNotfoundExcepation aex,WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND, aex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er) ;
		
	}
	
	@ExceptionHandler(DrivingLicIdNotFoundExcepation.class)
	public ResponseEntity<ErrorMassage> handleDrivingLicExcepation(DrivingLicIdNotFoundExcepation aex,WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND, aex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er) ;
		
	}
	
	@ExceptionHandler(FeedbackInNotFoundExcepation.class)
	public ResponseEntity<ErrorMassage> handleFeedbackExcepation(FeedbackInNotFoundExcepation aex,WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND, aex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er) ;
		
	}
	
	@ExceptionHandler(InsuranceIdNotFoundExcepation.class)
	public ResponseEntity<ErrorMassage> handleInsuranceExcepation(InsuranceIdNotFoundExcepation aex,WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND, aex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er) ;
		
	}
	
	@ExceptionHandler(LearningLicIdNotFoundExcepation.class)
	public ResponseEntity<ErrorMassage> handleLearningLicExcepation(LearningLicIdNotFoundExcepation aex,WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND, aex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er) ;
		
	}
	
	@ExceptionHandler(RtoOfficerIdNotFoundExcepation.class)
	public ResponseEntity<ErrorMassage> handleRtoOfficerExcepation(RtoOfficerIdNotFoundExcepation aex,WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND, aex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er) ;
		
	}
	
	
	@ExceptionHandler(UserrtoIdNotFoundExcepation.class)
	public ResponseEntity<ErrorMassage> handleUserrtoExcepation(UserrtoIdNotFoundExcepation aex,WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND, aex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er) ;
		
	}
	
	@ExceptionHandler(VehicleIdNotFoundExcepation.class)
	public ResponseEntity<ErrorMassage> handleVehicleExcepation(VehicleIdNotFoundExcepation aex,WebRequest request)
	{
		ErrorMassage er=new ErrorMassage(HttpStatus.NOT_FOUND, aex.getMessage());
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(er) ;
		
	}
	
}
