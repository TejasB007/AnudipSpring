package com.rtodemo.exception;

public class RtoOfficerIdNotFoundExcepation extends RuntimeException
{
	public RtoOfficerIdNotFoundExcepation(String message) 
	{
		super(message);
	}

}
