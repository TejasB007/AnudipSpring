package com.rtodemo.exception;

public class DrivingLicIdNotFoundExcepation extends RuntimeException
{
	public DrivingLicIdNotFoundExcepation(String message) 
	{
		super(message);
	}

}
