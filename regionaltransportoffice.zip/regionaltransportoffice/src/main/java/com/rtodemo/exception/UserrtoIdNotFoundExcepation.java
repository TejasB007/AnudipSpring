package com.rtodemo.exception;

public class UserrtoIdNotFoundExcepation extends RuntimeException
{
	public UserrtoIdNotFoundExcepation(String message) 
	{
		super(message);
	}

}
