package com.rtodemo.exception;

public class AdminrtoIdNotFoundExcepation extends RuntimeException
{
	public AdminrtoIdNotFoundExcepation (String message)
	{
		super(message);
	}


}
