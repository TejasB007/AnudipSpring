package com.rtodemo.exception;

public class ChallanIdNotfoundExcepation extends RuntimeException
{
	public ChallanIdNotfoundExcepation(String message) 
	{
		super(message);
	}

}
