package com.rtodemo.exception;

public class FeedbackInNotFoundExcepation extends RuntimeException
{
	public FeedbackInNotFoundExcepation(String message) 
	{
		super(message);
	}

}
