package com.rtodemo.exception;

public class VehicleIdNotFoundExcepation extends RuntimeException
{
	public VehicleIdNotFoundExcepation(String message) 
	{
		super(message);
	}

}
