package com.rtodemo.exception;

public class InsuranceIdNotFoundExcepation extends RuntimeException
{
	public InsuranceIdNotFoundExcepation(String message) 
	{
		super(message);
	}

}
