package com.rtodemo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rtodemo.entity.Insurance;
import com.rtodemo.exception.InsuranceIdNotFoundExcepation;
import com.rtodemo.repository.InsuranceRepository;
import com.rtodemo.services.InsuranceServices;

@Service
public class InsuranceServicesImpl implements InsuranceServices
{
	@Autowired
	InsuranceRepository insReposit;

	@Override
	public Insurance addInsuranceDetails(Insurance insurance)
	{
		
		return insReposit.save(insurance);
	}

	@Override
	public Insurance getInsuranceDetails(int insid) 
	{
		return insReposit.findById(insid).orElseThrow(()->new InsuranceIdNotFoundExcepation("Insurance Id Not Correct"));
	}

	@Override // get data
	public Insurance updateInsuranceDetails(Insurance insurance, int insid) 
	{
		Insurance updateInsurance=insReposit.findById(insid).orElseThrow(()->new InsuranceIdNotFoundExcepation("Insurance Id Not Correct"));
		
		// set data
		updateInsurance.setOwnername(insurance.getOwnername());
		updateInsurance.setAmount(insurance.getAmount());
		updateInsurance.setOwnermail(insurance.getOwnermail());
		updateInsurance.setPolicytype(insurance.getPolicytype());
	
		// save data
		insReposit.save(updateInsurance);
		return updateInsurance;
	}

	@Override
	public void deleteInsuranceDetails(int insid) 
	{
		Insurance deleteInsurance=insReposit.findById(insid).orElseThrow(()->new InsuranceIdNotFoundExcepation("Insurance Id Not Correct"));
		insReposit.delete(deleteInsurance);
		
	}

	@Override
	public List<Insurance> getAllDetails(Insurance insurance) 
	{
		return insReposit.findAll();
	}

}
