package com.rtodemo.servicesimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rtodemo.entity.LearningLic;
import com.rtodemo.exception.LearningLicIdNotFoundExcepation;
import com.rtodemo.repository.LearningLicRepository;
import com.rtodemo.services.LearningLicServices;

@Service
public class LearningLicServicesImpl implements LearningLicServices
{
	@Autowired
	LearningLicRepository LerReposi;

	@Override
	public LearningLic addLearningLicDetails(LearningLic learninglic) 
	{
		
		return LerReposi.save(learninglic);
	}

	@Override
	public LearningLic getLearningLicDetails(int llid) 
	{
		
		return LerReposi.findById(llid).orElseThrow(()->new LearningLicIdNotFoundExcepation("Learning License Id is not correct"));
	}

	@Override   //get data
	public LearningLic updateLearningDetails(LearningLic learninglic, int llid) 
	{
		LearningLic updateLearningLic=LerReposi.findById(llid).orElseThrow(()->new LearningLicIdNotFoundExcepation("Learning License Id is not correct"));
		
		//set data
		updateLearningLic.setLlname(learninglic.getLlname());
		updateLearningLic.setLlpass(learninglic.getLlpass());
		
		//save data
		LerReposi.save(updateLearningLic);
		return updateLearningLic;
	}

	@Override
	public void deleteLearningLicDetails(int llid)
	{
		LearningLic deleteLearningLic=LerReposi.findById(llid).orElseThrow(()->new LearningLicIdNotFoundExcepation("Learning License Id is not correct"));
		LerReposi.delete(deleteLearningLic);
	}

}
