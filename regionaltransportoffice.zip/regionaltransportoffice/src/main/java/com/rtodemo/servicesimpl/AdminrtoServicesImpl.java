package com.rtodemo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Service;
import com.rtodemo.entity.Adminrto;
import com.rtodemo.exception.AdminrtoIdNotFoundExcepation;
import com.rtodemo.repository.AdminRepository;
import com.rtodemo.services.AdminrtoServices;

@Service
public class AdminrtoServicesImpl implements AdminrtoServices
{
	@Autowired
	AdminRepository Adminrepos;

	@Override
	public Adminrto addAdminrtoDetails(Adminrto adminrto) 
	{
		
		return Adminrepos.save(adminrto);
	}

	@Override
	public Adminrto getAdminDetails(int aid) 
	{
		
		return Adminrepos.findById(aid).orElseThrow(()->new AdminrtoIdNotFoundExcepation("Admin Id is not correct"));
		
	}

	@Override
	public Adminrto updateAdminrtoDetails(Adminrto adminrto, int aid)
	{
		Adminrto updateAdminrto=Adminrepos.findById(aid).orElseThrow(()->new AdminrtoIdNotFoundExcepation("Admin Id is not correct"));
		
		//set data
		updateAdminrto.setAname(adminrto.getAname());
		updateAdminrto.setApass(adminrto.getApass());
		
		//save data
		Adminrepos.save(updateAdminrto);
		return updateAdminrto;
	}

	@Override
	public void deleteAdminrtoDetails(int aid)
	{
		Adminrto deleteAdminrto=Adminrepos.findById(aid).orElseThrow(()->new AdminrtoIdNotFoundExcepation("Admin Id is not correct"));
		Adminrepos.delete(deleteAdminrto);
		
		
	}

	@Override
	public List<Adminrto> getAllDetails(Adminrto adminrto) 
	{
		return Adminrepos.findAll();
	}
	

}
