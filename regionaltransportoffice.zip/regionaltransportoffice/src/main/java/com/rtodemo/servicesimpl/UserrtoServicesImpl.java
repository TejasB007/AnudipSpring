package com.rtodemo.servicesimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rtodemo.entity.Userrto;
import com.rtodemo.exception.UserrtoIdNotFoundExcepation;
import com.rtodemo.repository.UserrtoRepository;
import com.rtodemo.services.UserrtoServices;

@Service
public class UserrtoServicesImpl implements UserrtoServices
{
	@Autowired
	UserrtoRepository userReposi;

	@Override
	public Userrto addUserrtoDetails(Userrto userrto) 
	{
		return userReposi.save(userrto);
	}

	@Override
	public Userrto getUserrtoDetails(int uid) 
	{
		return userReposi.findById(uid).orElseThrow(()->new UserrtoIdNotFoundExcepation("User Id is not Correct"));
	}

	@Override
	public Userrto updateUserrtoDetails(Userrto userrto, int uid) 
	{
		Userrto updateUserto=userReposi.findById(uid).orElseThrow(()->new UserrtoIdNotFoundExcepation("User Id is not Correct"));
		
		//set data
		
		updateUserto.setFirstname(userrto.getFirstname());
		updateUserto.setLastname(userrto.getLastname());
		updateUserto.setUadd(userrto.getUadd());
		updateUserto.setUmobile(userrto.getUmobile());
		updateUserto.setUpass(userrto.getUpass());
		
		//save data
		userReposi.save(updateUserto);
		return updateUserto; 
	}

	@Override
	public void deleteUserrtoDetails(int uid)
	{
		Userrto deleteUserrto=userReposi.findById(uid).orElseThrow(()->new UserrtoIdNotFoundExcepation("User Id is not Correct"));
		userReposi.delete(deleteUserrto);
		
	}

}
