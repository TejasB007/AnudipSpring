package com.rtodemo.servicesimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rtodemo.entity.RtoOfficer;
import com.rtodemo.exception.RtoOfficerIdNotFoundExcepation;
import com.rtodemo.repository.RtoRepository;
import com.rtodemo.services.RtoOfficerServices;

@Service
public class RtoOfficerServicesImpl implements RtoOfficerServices
{
	@Autowired
	RtoRepository rReposi;
	

	@Override
	public RtoOfficer addRtoOfficerDetails(RtoOfficer rtoofficer)
	{
		return rReposi.save(rtoofficer);
	}

	@Override
	public RtoOfficer getRtoOfficerDetails(int rid)
	{
		
		return rReposi.findById(rid).orElseThrow(()-> new RtoOfficerIdNotFoundExcepation("RTO Id is Not Correct"));
	}

	@Override
	public RtoOfficer updateRtoOfficerDetails(RtoOfficer rtoofficer, int rid) 
	{
		RtoOfficer updateRtoOfficer=rReposi.findById(rid).orElseThrow(()-> new RtoOfficerIdNotFoundExcepation("RTO Id is Not Correct"));
		
		//set data
		updateRtoOfficer.setRtoname(rtoofficer.getRtoname());
		updateRtoOfficer.setRtopass(rtoofficer.getRtopass());
		
		//save
		rReposi.save(updateRtoOfficer);
		return updateRtoOfficer;
		
	}

	@Override
	public void deleteRtoOfficerDetails(int rid) 
	{
		RtoOfficer deleteRtoOfficer=rReposi.findById(rid).orElseThrow(()-> new RtoOfficerIdNotFoundExcepation("RTO Id is Not Correct"));
		rReposi.delete(deleteRtoOfficer);
		
		
		
	}

}
