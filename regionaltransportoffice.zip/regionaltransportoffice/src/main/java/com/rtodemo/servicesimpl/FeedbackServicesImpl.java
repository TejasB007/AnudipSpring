package com.rtodemo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rtodemo.entity.Feedback;
import com.rtodemo.exception.FeedbackInNotFoundExcepation;
import com.rtodemo.repository.FeedbackRepository;
import com.rtodemo.services.FeedbackServices;

@Service
public class FeedbackServicesImpl implements FeedbackServices
{
	@Autowired
	FeedbackRepository fbResposi;

	@Override
	public Feedback addFeedbackDetails(Feedback feedback) {
		
		return fbResposi.save(feedback);
	}

	@Override
	public Feedback getFeedbackDetails(int fid) 
	{
		
		return fbResposi.findById(fid).orElseThrow(()->new FeedbackInNotFoundExcepation("Feedback Id is not correct")) ;
	}

	@Override
	public Feedback updateFeedbackDetails(Feedback feedback, int fid) 
	{
		Feedback updateFeedback=fbResposi.findById(fid).orElseThrow(()->new FeedbackInNotFoundExcepation("Feedback Id is not correct")) ;		
		
		//update data
		updateFeedback.setUsername(feedback.getUsername());
		updateFeedback.setFeedbacktext(feedback.getFeedbacktext());
		
		//save
		fbResposi.save(updateFeedback);
		return updateFeedback;
	}

	@Override
	public void deleteFeedbackDetails(int fid) 
	{
		Feedback deleteFeedback=fbResposi.findById(fid).orElseThrow(()->new FeedbackInNotFoundExcepation("Feedback Id is not correct")) ;		
		fbResposi.delete(deleteFeedback);
	}

	@Override
	public List<Feedback> getAllDetails(Feedback feedback)
	{
		return fbResposi.findAll();
	}

}
