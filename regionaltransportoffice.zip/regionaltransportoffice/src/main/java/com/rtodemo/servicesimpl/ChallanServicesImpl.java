package com.rtodemo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rtodemo.entity.Challan;
import com.rtodemo.exception.ChallanIdNotfoundExcepation;
import com.rtodemo.repository.challanRepository;
import com.rtodemo.services.ChallanServices;

@Service
public class ChallanServicesImpl implements ChallanServices
{
	@Autowired
	challanRepository chlReposi;

	@Override
	public Challan addChallanDetails(Challan challan) 
	{
		return chlReposi.save(challan);
	}

	@Override
	public Challan getChallanDetails(int cid) 
	{
		return chlReposi.findById(cid).orElseThrow(()->new ChallanIdNotfoundExcepation("Challan Id is Not Correct"));
	}

	@Override  //get data
	public Challan updateChallanDetails(Challan challan, int cid) 
	{
		Challan updateChallan=chlReposi.findById(cid).orElseThrow(()->new ChallanIdNotfoundExcepation("Challan Id is Not Correct"));
		
		//set data
		updateChallan.setVehNo(challan.getVehNo());
		updateChallan.setChassisNo(challan.getChassisNo());
		updateChallan.setAmount(challan.getAmount());
		
		//save
		
		chlReposi.save(updateChallan);
		return updateChallan;
	}

	@Override
	public void deleteChallanDetails(int cid)
	{
		Challan deleteChallan=chlReposi.findById(cid).orElseThrow(()->new ChallanIdNotfoundExcepation("Challan Id is Not Correct"));
		chlReposi.delete(deleteChallan);	
	}

	@Override
	public List<Challan> getAllDetails(Challan challan) 
	{
		return chlReposi.findAll();
	}

	

}
