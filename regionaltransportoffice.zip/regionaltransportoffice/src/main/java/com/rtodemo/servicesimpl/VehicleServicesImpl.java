package com.rtodemo.servicesimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rtodemo.entity.Userrto;
import com.rtodemo.entity.Vehicle;
import com.rtodemo.exception.VehicleIdNotFoundExcepation;
import com.rtodemo.repository.VehicleRepository;
import com.rtodemo.services.VehicleServices;

@Service
public class VehicleServicesImpl implements VehicleServices 
{
	@Autowired
	VehicleRepository VReposit;

	@Override
	public Vehicle addVehicleDetails(Vehicle vehicle) 
	{
		return VReposit.save(vehicle);
	}

	@Override
	public Vehicle getVehicleDetails(int vid) 
	{
		
		return VReposit.findById(vid).orElseThrow(()->new VehicleIdNotFoundExcepation("Student Id is not correct"));
	}

	@Override //get data
	public Vehicle updateVehicleDetails(Vehicle vehicle, int vid) 
	{
		Vehicle updateVehicle=VReposit.findById(vid).orElseThrow(()->new VehicleIdNotFoundExcepation("Student Id is not correct"));
		
		// set data
		updateVehicle.setVehownername(vehicle.getVehownername());
		updateVehicle.setVehaddress(vehicle.getVehaddress());
		
		// save 
		VReposit.save(updateVehicle);
		return updateVehicle;
	}

	@Override
	public void deleteVehicleDetails(int vid) 
	{
		Vehicle deleteVehicle=VReposit.findById(vid).orElseThrow(()->new VehicleIdNotFoundExcepation("Student Id is not correct"));
		VReposit.delete(deleteVehicle);
	}
	
	
	

}
