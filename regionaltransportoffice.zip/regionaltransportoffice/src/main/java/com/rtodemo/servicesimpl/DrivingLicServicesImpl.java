package com.rtodemo.servicesimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rtodemo.entity.DrivingLic;
import com.rtodemo.exception.DrivingLicIdNotFoundExcepation;
import com.rtodemo.repository.DrivingLicRepository;
import com.rtodemo.services.DrivingLicServices;

@Service
public class DrivingLicServicesImpl implements DrivingLicServices 
{
	@Autowired
	DrivingLicRepository DLReposi;

	@Override
	public DrivingLic addDrivingLicDetails(DrivingLic drivinglic) 
	{
		
		return DLReposi.save(drivinglic);
	}

	@Override
	public DrivingLic getDrivingLicDetails(int dlid) 
	{
		
		return DLReposi.findById(dlid).orElseThrow(()->new DrivingLicIdNotFoundExcepation("Driving License Id is not correct"));
	}

	@Override  //get data
	public DrivingLic updateDrivingLicDetails(DrivingLic drivinglic, int dlid) 
	{
		DrivingLic updateDrivingLic=DLReposi.findById(dlid).orElseThrow(()->new DrivingLicIdNotFoundExcepation("Driving License Id is not correct"));
		
		//set data
		updateDrivingLic.setDlname(drivinglic.getDlname());
		updateDrivingLic.setDladd(drivinglic.getDladd());
		updateDrivingLic.setDlpass(drivinglic.getDlpass());
		
		// save data
		DLReposi.save(updateDrivingLic);
		return updateDrivingLic;
	}

	@Override
	public void deleteDrivingLicDetails(int dlid)
	{
		DrivingLic deleteDrivingLic=DLReposi.findById(dlid).orElseThrow(()->new DrivingLicIdNotFoundExcepation("Driving License Id is not correct"));
		DLReposi.delete(deleteDrivingLic);
		
	}

	@Override
	public List<DrivingLic> getAllDetails(DrivingLic drivingLic) {
		
		return DLReposi.findAll();
	}

}
