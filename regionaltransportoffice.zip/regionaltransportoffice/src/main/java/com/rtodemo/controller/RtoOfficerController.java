package com.rtodemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rtodemo.entity.RtoOfficer;
import com.rtodemo.services.RtoOfficerServices;

import jakarta.validation.Valid;

@RestController
public class RtoOfficerController 
{
	@Autowired
	RtoOfficerServices rtoServices;
	
	//http://localhost:8080/RtoOfficer/addRtoOfficer
	@PostMapping("/RtoOfficer/addRtoOfficer")
	public ResponseEntity<RtoOfficer>saveRtoOfficer(@Valid @RequestBody RtoOfficer rtoOfficer)
	{
		return new ResponseEntity<RtoOfficer>(rtoServices.addRtoOfficerDetails(rtoOfficer),HttpStatus.CREATED);
		
		
	}
	
	//http://localhost:8080/RtoOfficer/getRtoOfficer/2
	@GetMapping("/RtoOfficer/getRtoOfficer/{rid}")
	public ResponseEntity<RtoOfficer>getRtoOfficer(@PathVariable("rid")int rid)
	{
		return new ResponseEntity<RtoOfficer>(rtoServices.getRtoOfficerDetails(rid),HttpStatus.OK);
		
		
	}
	
	//http://localhost:8080/RtoOfficer/removeRtoOfficer/1
	@DeleteMapping("/RtoOfficer/removeRtoOfficer/{rid}")
	public ResponseEntity<String>deleteRtoOfficer(@PathVariable("rid")int rid)
	{
		rtoServices.deleteRtoOfficerDetails(rid);
		return new ResponseEntity<String>("Delete RTO Officer Suceessfully......",HttpStatus.OK) ;
		
	} 
	
	//http://localhost:8080/RtoOfficer/editRtoOfficer/1
	@PutMapping("/RtoOfficer/editRtoOfficer/{rid}")
	public ResponseEntity<RtoOfficer>editRtoOfficer(@Valid@PathVariable("rid")int rid ,@RequestBody RtoOfficer rtoOfficer)
	{
		return new ResponseEntity<RtoOfficer>(rtoServices.updateRtoOfficerDetails(rtoOfficer, rid),HttpStatus.OK );
		
	}

}
