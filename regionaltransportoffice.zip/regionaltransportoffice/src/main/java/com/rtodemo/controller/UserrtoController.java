package com.rtodemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rtodemo.entity.Userrto;
import com.rtodemo.services.UserrtoServices;

import jakarta.validation.Valid;

@RestController
public class UserrtoController 
{
	@Autowired
	UserrtoServices uServices;
	
	//http://localhost:8080/Userrto/addUserrto
	@PostMapping("/Userrto/addUserrto")
	public ResponseEntity<Userrto>saveUser(@Valid @RequestBody Userrto userrto)
	{
		return new ResponseEntity<Userrto>(uServices.addUserrtoDetails(userrto),HttpStatus.CREATED);
		
	}
	
	//http://localhost:8080/Userrto/getUserrto/1
	@GetMapping("/Userrto/getUserrto/{uid}")
	public ResponseEntity<Userrto>getUser(@PathVariable("uid")int uid)
	{
		return new ResponseEntity<Userrto>(uServices.getUserrtoDetails(uid),HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Userrto/removeUserrto/1
	@DeleteMapping("/Userrto/removeUserrto/{uid}")
	public ResponseEntity<String>deleteUser(@PathVariable("uid")int uid)
	{
		uServices.deleteUserrtoDetails(uid);
		return new ResponseEntity<String>("Delete User Data Sucessfully...........",HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Userrto/editUserrto/1
	@PutMapping("/Userrto/editUserrto/{uid}")
	public ResponseEntity<Userrto>editUser(@Valid @PathVariable("uid") int uid,@RequestBody Userrto userrto)
	{
		return new ResponseEntity<Userrto>(uServices.updateUserrtoDetails(userrto, uid),HttpStatus.OK) ;
		
	} 

}
