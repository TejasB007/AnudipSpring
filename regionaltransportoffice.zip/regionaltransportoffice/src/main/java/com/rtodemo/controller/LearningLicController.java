package com.rtodemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rtodemo.entity.LearningLic;
import com.rtodemo.services.LearningLicServices;

import jakarta.validation.Valid;

@RestController
public class LearningLicController 
{
	@Autowired
	LearningLicServices LearServices;
	
	//http://localhost:8080/LearningLic/addLearningLic
	@PostMapping("/LearningLic/addLearningLic")
	public ResponseEntity<LearningLic>saveLearningLic(@Valid@RequestBody LearningLic learningLic)
	{
		return new ResponseEntity<LearningLic>(LearServices.addLearningLicDetails(learningLic),HttpStatus.CREATED);
		
	}
	
	//http://localhost:8080/LearningLic/getLearningLic/2
	@GetMapping("/LearningLic/getLearningLic/{llid}")
	public ResponseEntity<LearningLic>getLearningLic(@PathVariable("llid")int llid)
	{
		return new ResponseEntity<LearningLic>(LearServices.getLearningLicDetails(llid),HttpStatus.OK);
		
		
	}
	
	//http://localhost:8080/LearningLic/removeLearningLic/2
	@DeleteMapping("/LearningLic/removeLearningLic/{llid}")
	public ResponseEntity<String>deleteLearningLic(@PathVariable("llid") int llid)
	{
		LearServices.deleteLearningLicDetails(llid);
		return new ResponseEntity<String>("Delete Learning License Data Suceessfully........",HttpStatus.OK);
		
	}
	
	//http://localhost:8080/LearningLic/editLearningLic/1
	@PutMapping("/LearningLic/editLearningLic/{llid}")
	public ResponseEntity<LearningLic>editLearningLic(@Valid@PathVariable("llid")int llid,@RequestBody LearningLic learninglic)
	{
		return new ResponseEntity<LearningLic>(LearServices.updateLearningDetails(learninglic, llid),HttpStatus.OK);
	}
	
	
	

}
