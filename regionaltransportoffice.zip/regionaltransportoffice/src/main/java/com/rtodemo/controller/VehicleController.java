package com.rtodemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rtodemo.entity.Vehicle;
import com.rtodemo.services.VehicleServices;

import jakarta.validation.Valid;

@RestController
public class VehicleController 
{
	@Autowired
	VehicleServices VServices;
	
	//http://localhost:8080/Vehicle/addVehicle
	@PostMapping("/Vehicle/addVehicle")
	public ResponseEntity<Vehicle>saveVehicle(@Valid @RequestBody Vehicle vehicle)
	{
		return new ResponseEntity<Vehicle>(VServices.addVehicleDetails(vehicle),HttpStatus.CREATED);
		
	}
	
	//http://localhost:8080/Vehicle/getVehicle/1
	@GetMapping("/Vehicle/getVehicle/{vid}")
	public ResponseEntity<Vehicle>getVehicle(@PathVariable("vid")int vid)
	{
		return new ResponseEntity<Vehicle>(VServices.getVehicleDetails(vid),HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Vehicle/deleteVehicle/1
	@DeleteMapping("/Vehicle/deleteVehicle/{vid}")
	public ResponseEntity<String>deleteVehicle(@PathVariable("vid")int vid)
	{
		VServices.deleteVehicleDetails(vid);
		return new ResponseEntity<String>("Delete Vehicle Data Sucessfully............",HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Vehicle/editVehicle/1
	@PutMapping("/Vehicle/editVehicle/{vid}")
	public ResponseEntity<Vehicle>editVehicle(@Valid @PathVariable("vid")int vid,@RequestBody Vehicle vehicle)
	{
		return new ResponseEntity<Vehicle>(VServices.updateVehicleDetails(vehicle, vid),HttpStatus.OK);
		
	} 

}
