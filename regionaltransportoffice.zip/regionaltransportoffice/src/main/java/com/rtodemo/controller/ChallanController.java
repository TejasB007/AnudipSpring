package com.rtodemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rtodemo.entity.Challan;
import com.rtodemo.services.ChallanServices;

import jakarta.validation.Valid;

@CrossOrigin(origins ="http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class ChallanController 
{
	@Autowired
	ChallanServices chlservices;
	
	//http://localhost:8080/Challan/addchallan
	@PostMapping("/Challan")
	public ResponseEntity<Challan>saveChallan(@Valid@RequestBody Challan challan)
	{
		return new ResponseEntity<Challan>(chlservices.addChallanDetails(challan),HttpStatus.CREATED) ;
		
	}
	
	//http://localhost:8080/Challan/getchallan/1
	@GetMapping("/Challan/{cid}")
	public ResponseEntity<Challan>getChallan(@PathVariable("cid") int cid)
	{
		return new ResponseEntity<Challan>(chlservices.getChallanDetails(cid),HttpStatus.OK);	
	}
	
	//http://localhost:8080/Challan/removechallan/1
	@DeleteMapping("/Challan/{cid}")
	public ResponseEntity<String>deleteChallan(@PathVariable("cid")int cid)
	{
		chlservices.deleteChallanDetails(cid);
		return new ResponseEntity<String>("Delete Challan Suceessfully.......",HttpStatus.OK) ;
		
	}
	
	//http://localhost:8080/Challan/editchallan/1
	@PutMapping("/Challan/{cid}")
	public ResponseEntity<Challan>editChallan(@Valid @PathVariable("cid") int cid,@RequestBody Challan challan)
	{
		return new ResponseEntity<Challan>(chlservices.updateChallanDetails(challan, cid),HttpStatus.OK) ;
		
	}
	
	@GetMapping("/Challan/All")
	public ResponseEntity<List>getAllChallan(Challan challan)
	{
		return new ResponseEntity<List>(chlservices.getAllDetails(challan),HttpStatus.OK);
		
	}
	
	
	

}
