package com.rtodemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rtodemo.entity.DrivingLic;
import com.rtodemo.services.DrivingLicServices;

import jakarta.validation.Valid;

@CrossOrigin(origins ="http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class DrivingLicController 
{
	@Autowired
	DrivingLicServices DLServices;
	
	//http://localhost:8080/DrivingLic/addDrivingLic
	@PostMapping("/DrivingLic")
	public ResponseEntity<DrivingLic>saveDrivingLic(@Valid @RequestBody DrivingLic drivingLic)
	{
		return new ResponseEntity<DrivingLic>(DLServices.addDrivingLicDetails(drivingLic),HttpStatus.CREATED);
		
	}
	
	//http://localhost:8080/DrivingLic/getDrivingLic/1
	@GetMapping("/DrivingLic/{dlid}")
	public ResponseEntity<DrivingLic>getDrivingLic(@PathVariable ("dlid") int dlid)
	{
		return new ResponseEntity<DrivingLic>(DLServices.getDrivingLicDetails(dlid),HttpStatus.OK);
		
	}
	
	//http://localhost:8080/DrivingLic/removeDrivingLic/1
	@DeleteMapping("/DrivingLic/{dlid}")
	public ResponseEntity<String>deleteDrivingLic(@PathVariable("dlid")int dlid)
	{
		DLServices.deleteDrivingLicDetails(dlid);
		
		return new ResponseEntity<String>("Delete Driving License data Suceessfully........",HttpStatus.OK);
		
	}
	
	//http://localhost:8080/DrivingLic/editDrivingLic/1
	@PutMapping("/DrivingLic/{dlid}")
	public ResponseEntity<DrivingLic>editDrivingLic(@Valid@PathVariable ("dlid")int dlid,@RequestBody DrivingLic drivingLic)
	{
		return new  ResponseEntity<DrivingLic>(DLServices.updateDrivingLicDetails(drivingLic, dlid),HttpStatus.OK) ;
		
	}
	
	@GetMapping("/DrivingLic/All")
	public ResponseEntity<List>getAllDrivingLic(DrivingLic drivingLic)
	{
		return new ResponseEntity<List>(DLServices.getAllDetails(drivingLic),HttpStatus.OK);
		
	}
	

}
