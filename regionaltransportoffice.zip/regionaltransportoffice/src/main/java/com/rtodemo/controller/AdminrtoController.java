package com.rtodemo.controller;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rtodemo.entity.Adminrto;
import com.rtodemo.services.AdminrtoServices;

import jakarta.validation.Valid;

@CrossOrigin(origins ="http://localhost:4200")
@RestController
@RequestMapping("/api/v1")
public class AdminrtoController 
{
	@Autowired
	AdminrtoServices admservices;
	

	//http://localhost:8080/Adminrto/addAdminrto
	@PostMapping("/Adminrto")
	public ResponseEntity<Adminrto>saveAdminrto(@Valid @RequestBody Adminrto adminrto)
	{
		return new ResponseEntity<Adminrto>(admservices.addAdminrtoDetails(adminrto),HttpStatus.CREATED);
		
	}
	
	//http://localhost:8080/Adminrto/getAdminrto/1
	@GetMapping("/Adminrto/{aid}")
	public ResponseEntity<Adminrto>getAdminrto(@PathVariable("aid") int aid)
	{
		
		return new ResponseEntity<Adminrto>(admservices.getAdminDetails(aid),HttpStatus.OK);
		
	}
	
	//http://locathost:8080/Adminrto/remove/1
	@DeleteMapping("/Adminrto/{aid}")
	public ResponseEntity<String>deleteAdmin(@PathVariable("aid") int aid)
	{
		admservices.deleteAdminrtoDetails(aid);
		
		return new ResponseEntity<String>("Delete Admin Data Suceessfully........",HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Adminrto/editAdmin/1
	@PutMapping("/Adminrto/{aid}")
	public ResponseEntity<Adminrto>editAdmin(@Valid @PathVariable("aid") int aid,@RequestBody Adminrto adminrto)
	{
		return new ResponseEntity<Adminrto>(admservices.updateAdminrtoDetails(adminrto, aid),HttpStatus.OK) ;
		
	}   
	
	//http://localhost:8080/Adminrto/All
	@GetMapping("/Adminrto/All")
	public ResponseEntity<List>getAllAdmin(Adminrto adminrto)
	{
		return new ResponseEntity<List>(admservices.getAllDetails(adminrto),HttpStatus.OK);
		
	}
	
	
}
