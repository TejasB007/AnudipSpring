package com.rtodemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.rtodemo.entity.Feedback;
import com.rtodemo.services.FeedbackServices;

import jakarta.validation.Valid;

@RestController
public class FeedbackController 
{
	@Autowired
	FeedbackServices fbServices;
	
	//http://localhost:8080/Feedback/addFeedback
	@PostMapping("/Feedback/addFeedback")
	public ResponseEntity<Feedback>saveFeedback(@Valid @RequestBody Feedback feedback)
	{
		return new ResponseEntity<Feedback>(fbServices.addFeedbackDetails(feedback),HttpStatus.CREATED) ;
		
	}
	
	//http://localhost:8080/Feedback/getFeedback/2
	@GetMapping("/Feedback/getFeedback/{fid}")
	public ResponseEntity<Feedback>getFeedback(@PathVariable("fid")int fid)
	{
		return new ResponseEntity<Feedback>(fbServices.getFeedbackDetails(fid),HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Feedback/removeFeedback/2
	@DeleteMapping("/Feedback/removeFeedback/{fid}")
	public ResponseEntity<String>deleteFeedback(@PathVariable("fid")int fid)
	{
		fbServices.deleteFeedbackDetails(fid);
		return new ResponseEntity<String>("Delete Feedback Suceessfully.....",HttpStatus.OK);
		
	}
	
	//http://localhost:8080/Feedback/editFeedback/2
	@PutMapping("/Feedback/editFeedback/{fid}")
	public ResponseEntity<Feedback>editFeedback(@Valid @PathVariable("fid")int fid,@RequestBody Feedback feedback)
	{
		return new ResponseEntity<Feedback>(fbServices.updateFeedbackDetails(feedback, fid),HttpStatus.OK) ;
		
	}
	
	@GetMapping("Feedback/All")
	public ResponseEntity<List>getAllFeedback(Feedback feedback)
	{
		return new ResponseEntity<List>(fbServices.getAllDetails(feedback),HttpStatus.OK);
		
	}

}
