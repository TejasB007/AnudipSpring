package com.rtodemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rtodemo.entity.Challan;

public interface challanRepository extends JpaRepository<Challan, Integer>
{

}
