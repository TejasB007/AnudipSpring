package com.rtodemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rtodemo.entity.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Integer> 
{
	

}
