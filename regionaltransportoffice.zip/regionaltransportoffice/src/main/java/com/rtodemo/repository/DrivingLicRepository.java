package com.rtodemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rtodemo.entity.DrivingLic;

public interface DrivingLicRepository extends JpaRepository<DrivingLic, Integer>
{

}
