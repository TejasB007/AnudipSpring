package com.rtodemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rtodemo.entity.Feedback;


public interface FeedbackRepository extends JpaRepository<Feedback, Integer>
{

}
