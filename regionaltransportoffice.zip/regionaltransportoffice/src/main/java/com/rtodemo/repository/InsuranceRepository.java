package com.rtodemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rtodemo.entity.Insurance;

public interface InsuranceRepository extends JpaRepository<Insurance, Integer>
{

}
