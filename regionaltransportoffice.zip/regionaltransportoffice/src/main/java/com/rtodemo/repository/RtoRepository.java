package com.rtodemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rtodemo.entity.RtoOfficer;

public interface RtoRepository extends JpaRepository<RtoOfficer, Integer>
{

}
