package com.rtodemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rtodemo.entity.Userrto;

public interface UserrtoRepository extends JpaRepository<Userrto, Integer>
{

}
