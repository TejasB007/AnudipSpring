package com.rtodemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rtodemo.entity.LearningLic;

public interface LearningLicRepository extends JpaRepository<LearningLic, Integer> 
{
	

}
