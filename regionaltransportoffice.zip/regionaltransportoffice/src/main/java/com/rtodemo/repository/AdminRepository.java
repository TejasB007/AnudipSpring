package com.rtodemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rtodemo.entity.Adminrto;

public interface AdminRepository extends JpaRepository<Adminrto, Integer>
{

}
