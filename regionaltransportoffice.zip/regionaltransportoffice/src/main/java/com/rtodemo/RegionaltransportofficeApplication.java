package com.rtodemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegionaltransportofficeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegionaltransportofficeApplication.class, args);
	}

}
