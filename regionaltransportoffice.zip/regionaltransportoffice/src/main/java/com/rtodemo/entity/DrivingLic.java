package com.rtodemo.entity;

import jakarta.persistence.Column; 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Entity
@Table(name="drivlic")
public class DrivingLic
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int dlid; 
	
	@Column(length = 25, nullable = false)
	@NotBlank(message = "Driving Licene Name cannot be blank...")
	private String dlname;
	
	@Column(length=100, nullable = false)
	@NotBlank(message = "Driving Licene Address cannot be blank.....")
	private String dladd;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Driving Licene Date of Birth cannot be blank ...")
	private String dldob;
	
	@Column(length=25, nullable = false)
	@NotNull(message = "Driving Learning Licene Number cannot be blank ...")
	private int dllno;
	
	@Column(length=25, nullable = false,unique = true)
	@NotBlank(message = "Driving Licene cannot be blank .....")
	private String dlpass;
	
	@Column(length=25, nullable = false)
	//@NotBlank(message = "Driving Licene Test Marks cannot be blank......")
	private int dltestmark;
	
	/*
	 * @OneToOne
	 * 
	 * @JoinColumn(name = "ledrivId") 
	 * private LearningLic learninglic;
	 */
	
	
	
	


}
