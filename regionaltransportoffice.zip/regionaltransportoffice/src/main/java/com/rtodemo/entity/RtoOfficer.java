package com.rtodemo.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity 
public class RtoOfficer 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int rid;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "RTO Officer Name cannot be blank .....")
	private String rtoname;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "RTO Officer Password cannot be blank.....")
	private String rtopass;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "RTO Officer ID Card cannot be blank.....")
	private String rtoidcard;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "RTO Officer E-mail cannot be blank ...")
	@Email(message = "Email id is not proper")
	private String rtoemail;
	
	
	/*@OneToMany(mappedBy = "rtooffic",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JsonManagedReference
	List<Adminrto>adminrtilist;
	*/

}
