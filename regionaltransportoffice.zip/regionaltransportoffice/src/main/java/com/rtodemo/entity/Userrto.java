package com.rtodemo.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Entity
public class Userrto
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int uid;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "User Name cannot be blank......")
	private String uname; 
	
	@Column(length=25, nullable = false,unique = true)
	@NotBlank(message = "User Password cannot be blank......")
	private String upass;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "User E-mail cannot be blank......")
	@Email(message = "Email id is not proper")
	private String uemail;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "User first Name cannot be blank......")
	private String firstname;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "User last Name cannot be blank......")
	private String lastname;
	
	@Size(min=10, max=10, message = "Min and Max 10 digits allowed")
	@Column(length=10, nullable = false)
	@NotBlank(message = "User Mobile cannot be blank......")
	private Boolean umobile;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "User Date of birth cannot be blank......")
	private String udob;
	
	@Column(length=100, nullable = false)
	@NotBlank(message = "User Address cannot be blank......")
	private String uadd;
	
	
	@OneToMany(mappedBy = "userrto",fetch =FetchType.EAGER,cascade = CascadeType.ALL )
	@JsonManagedReference
	List<LearningLic>learninglist;
	
	@OneToMany(mappedBy = "userrto1",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JsonManagedReference
	List<Vehicle>vehiclelist;
	
	
	@OneToMany(mappedBy = "userrto1",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JsonManagedReference
	List<Feedback>feedbacklist;
	
	@OneToMany(mappedBy = "userrto1",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JsonManagedReference
	List<Insurance>insuranceslist;
	
	
	
}
