package com.rtodemo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;


@Data
@Entity
public class Vehicle 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int vid;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Registration Number cannot be blank......")
	private String Vehregistrationno;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle type cannot be blank......")
	private String vehicletype;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Owner Name cannot be blank......")
	private String vehownername;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Address cannot be blank......")
	private String vehaddress;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Model Number cannot be blank......")
	private String vehiclemodel;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Year Of Manufactur cannot be blank......")
	private String yearofmanufacture;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Engine Number cannot be blank......")
	private String enginenumber;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Chassis Number cannot be blank......")
	private String chassisnumber;

	
	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "useId",referencedColumnName = "uid")
	@JsonBackReference
	private Userrto userrto1;
	
}


