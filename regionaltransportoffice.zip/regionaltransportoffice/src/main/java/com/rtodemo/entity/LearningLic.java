package com.rtodemo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity
@Table(name = "Learning")
public class LearningLic
{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int llid;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Learning License Name cannot be blank")
	private String llname;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Learning License Address cannot be blank")
	private String lladd;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Learning License date of birth cannot be blank")
	private String lldob;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Learning License E-Mail cannot be blank")
	@Email(message = "Email id is not proper")
	private String llmail;
	
	@Column(length=25, nullable = false,unique = true)
	@NotBlank(message = "Learning License Pass cannot be blank")
	private String llpass;
	
	@Column(length=25, nullable = false)
	//@NotBlank(message = "Admin Name cannot be blank")
	private int lltestmark;
	
	
	@ManyToOne( fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="userID", referencedColumnName = "uid")
	@JsonBackReference
	private Userrto userrto;
	
	/*
	 * @OneToOne(mappedBy = "learninglic",cascade = CascadeType.ALL) 
	 * private DrivingLic drivinglic;
	 *
	 */
}
