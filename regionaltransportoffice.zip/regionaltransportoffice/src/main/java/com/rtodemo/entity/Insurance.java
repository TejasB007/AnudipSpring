package com.rtodemo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity
@Table(name = "insur")
public class Insurance 
{ 
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int insid;
	
	@Column(length=25, nullable = false)
	//@NotBlank(message = "Vehicle Id cannot be blank...")	
	private int  vehicleid;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Insurance Policy Type cannot be blank...")	
	private String policytype;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Registeration Number cannot be blank...")	
	private String vehregisno;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Owner Name cannot be blank...")	
	private String ownername;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Owner E-Mail cannot be blank...")
	@Email(message = "Email id is not proper")
	private String ownermail;
	
	@Column(length=25, nullable = false)
	//@NotBlank(message = "Amount cannot be blank...")
	private Boolean amount; 
	
	@ManyToOne(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JoinColumn(name = "insuserId",referencedColumnName = "uid")
	@JsonBackReference
	private Userrto userrto1;
	

	
}
