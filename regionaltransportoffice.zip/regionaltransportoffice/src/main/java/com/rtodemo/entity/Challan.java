package com.rtodemo.entity;

import jakarta.persistence.Column; 
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity
@Table(name = "challan_details")
public class Challan 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cid;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Chassis Number cannot be blank fill the Vehicle Number...")
	private String vehNo; 
	
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Vehicle Chassis Number cannot be blank fill the Vehicle Chassis Number...")
	private String chassisNo;
	
	@Column(length=25, nullable = false)
	@NotBlank(message = "Challan Amount cannot be blank.....")
	private String amount;
	
	

}
