package com.rtodemo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
@Entity
@Table (name="feedb")
public class Feedback 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int fid;
	
	@Column(length = 25,nullable =  false)
	@NotBlank(message = "User Name cannot be blank fill the User Name Name...")
	private String username;
	
	@Column (length = 25)
	private String feedbackdate;
	
	@Column (length = 50,nullable = false)
	@NotBlank(message = "Feedback Text cannot be blank fill the Feedback Text Name...")
	private String feedbacktext;
	
	
	@ManyToOne(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JoinColumn(name = "userId",referencedColumnName = "uid")
	@JsonBackReference
	private Userrto userrto1;
	
	
}
