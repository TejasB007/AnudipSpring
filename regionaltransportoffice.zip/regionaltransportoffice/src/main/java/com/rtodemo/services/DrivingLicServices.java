package com.rtodemo.services;

import java.util.List;

import com.rtodemo.entity.DrivingLic;

public interface DrivingLicServices 
{
	DrivingLic addDrivingLicDetails(DrivingLic drivinglic);
	DrivingLic getDrivingLicDetails(int dlid);
	DrivingLic updateDrivingLicDetails(DrivingLic drivinglic,int dlid);
	void deleteDrivingLicDetails(int dlid);
	
	List<DrivingLic>getAllDetails(DrivingLic drivingLic);
}

