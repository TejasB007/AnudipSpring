package com.rtodemo.services;

import com.rtodemo.entity.Userrto;

public interface UserrtoServices 
{
	
	Userrto addUserrtoDetails(Userrto userrto);
	Userrto getUserrtoDetails(int uid);
	Userrto updateUserrtoDetails(Userrto userrto ,int uid);
	void deleteUserrtoDetails(int uid);
	

}

