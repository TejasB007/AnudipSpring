package com.rtodemo.services;


import java.util.List;

import com.rtodemo.entity.Adminrto;

public interface AdminrtoServices 
{
	Adminrto addAdminrtoDetails(Adminrto adminrto);
	Adminrto getAdminDetails(int aid);
	Adminrto updateAdminrtoDetails(Adminrto adminrto,int aid);
	void deleteAdminrtoDetails(int aid);
	List<Adminrto>getAllDetails(Adminrto adminrto);

}
