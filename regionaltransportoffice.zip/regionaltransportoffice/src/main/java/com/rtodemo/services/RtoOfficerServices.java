package com.rtodemo.services;

import com.rtodemo.entity.RtoOfficer;

public interface RtoOfficerServices 
{
	
	RtoOfficer addRtoOfficerDetails(RtoOfficer rtoofficer);
	RtoOfficer getRtoOfficerDetails(int rid);
	RtoOfficer updateRtoOfficerDetails(RtoOfficer rtoofficer,int rid);
	void deleteRtoOfficerDetails(int rid);
	
	

}