package com.rtodemo.services;

import java.util.List;

import com.rtodemo.entity.Insurance;

public interface InsuranceServices 
{
	Insurance addInsuranceDetails(Insurance insurance);
	Insurance getInsuranceDetails(int insid);
	Insurance updateInsuranceDetails(Insurance insurance,int insid);
	void deleteInsuranceDetails(int insid);
	
	List<Insurance>getAllDetails(Insurance insurance);

}

