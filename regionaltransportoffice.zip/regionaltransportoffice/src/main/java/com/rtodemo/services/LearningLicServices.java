package com.rtodemo.services;

import com.rtodemo.entity.LearningLic;

public interface LearningLicServices 
{
	
	LearningLic addLearningLicDetails(LearningLic learninglic);
	LearningLic getLearningLicDetails(int llid);
	LearningLic updateLearningDetails(LearningLic learninglic,int llid);
	void deleteLearningLicDetails(int llid);
	

}


