package com.rtodemo.services;

import com.rtodemo.entity.Vehicle;

public interface VehicleServices 
{
	
	Vehicle addVehicleDetails(Vehicle vehicle);
	Vehicle getVehicleDetails(int vid);
	Vehicle updateVehicleDetails(Vehicle vehicle,int vid);
	void deleteVehicleDetails(int vid);
	



}

