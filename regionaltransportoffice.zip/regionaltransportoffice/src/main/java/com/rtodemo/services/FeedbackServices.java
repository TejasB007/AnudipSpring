package com.rtodemo.services;

import java.util.List;

import com.rtodemo.entity.Feedback;

public interface FeedbackServices
{ 
	Feedback addFeedbackDetails(Feedback feedback );
	Feedback getFeedbackDetails(int fid);
	Feedback updateFeedbackDetails(Feedback feedback ,int fid);
	void deleteFeedbackDetails(int fid);
	
	List<Feedback>getAllDetails(Feedback feedback);

}


