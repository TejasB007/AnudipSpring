package com.rtodemo.services;

import java.util.List;

import com.rtodemo.entity.Challan;

public interface ChallanServices 
{
	Challan addChallanDetails(Challan challan);
	Challan getChallanDetails(int cid);
	Challan updateChallanDetails(Challan challan ,int cid);
	void deleteChallanDetails(int cid);
	List<Challan>getAllDetails(Challan challan);
	

}